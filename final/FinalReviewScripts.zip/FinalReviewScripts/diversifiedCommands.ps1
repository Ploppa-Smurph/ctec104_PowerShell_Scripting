﻿#command to display the error messages in the System log?
get-eventlog System –EntryType Error 
# To display all processes that their proprty handles is greater than 500 
get-process | where {$_.handles -gt 1000}
get-help get-command -online
# To list all running services?
Get-Service | Where-Object {$_.Status -eq “Running”}
#To display all services and sort by DisplayName value
Get-Service “s*” | Sort-Object DisplayName
