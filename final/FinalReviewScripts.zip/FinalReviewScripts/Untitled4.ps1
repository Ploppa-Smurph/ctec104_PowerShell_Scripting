﻿#get-help get-date –online 
#get-help get-date –full 
cls 
$a=get-eventlog -logname "windows powershell" -entrytype information
$a | select -index 0, ($a.count-1) 