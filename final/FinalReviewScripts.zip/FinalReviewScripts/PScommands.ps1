﻿cls
$d = get-date 
$d.ToShortDateString()	
$d.ToLongDateString()
$answer= read-host " enter any key to continue to display all processes   "  
get-process | where {$_.handles -gt 500} 

$answer= read-host " enter any key to continue to display all processes   "  
# dir or list is an alias of get-childitem 
get-childitem *.ps1
