﻿#Event log commands in Poweshell 
#Author: Dr Ahmed 
#Title: Intro to scripting CTEC104 
#---------------------------------
#do statement body

do 
{ Clear-host 
  write-host "L I S T  of Event Log commands " 
  write-host "  " 
  write-host "    To see the log events of this computer... Type 1" 
  write-host "    To display all properties of an event...Type 2 "
  write-host "    To display the first and last element of array a...Type 3"
  write-host "    To check your drives and store date in a file...type 4"
  write-host " "
   $answer = read-host " Type [1-5] and [0] to Quit " 
# if you type 1 you should be able to store and display the 
#log events of your local computer 
   if ($answer -eq 1)
    { get-eventlog  -list  | out-file myevents.txt
      type myevents.txt | more
      $ans = read-host " enter any key to continue " 
     }
    
#if you select 2, you should be able to display all the property value of an event (the most recent. 
#--------------------------------------------------------------------------------------------------
if ($answer -eq 2)
    {  get-eventlog  -logName system -Newest 1
       $a | Select-Object -Property * | Out-File allProperties.txt
       type allProperties.txt
       $ans = read-host " enter any key to continue " 
    }
    if ($answer -eq 3)
    { $a = Get-EventLog -logname "Windows powershell" 
      $a | Select-Object -index 0, ($a.count - 1)
      $ans = read-host " enter any key to continue " 
     }
#run Ps-drive and store the output into a file mydrives 
    if ($answer -eq 4)
    {   Get-PSDrive | out-file mydrives 
        type mydrives 
        $ans = read-host " enter any key to continue " 

     }

     
 } while ($answer -ne 0) 
  
