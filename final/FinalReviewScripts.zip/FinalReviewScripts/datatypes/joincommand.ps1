﻿#join command 
cls 
#join with no space separator 
-join ("Windows", "PowerShell", "2.0")
# join command with a space in between 
"Windows", "PowerShell", "2.0" -join " " 
#-- use a multiple-character delimiter to join 
#three strings:
$a = "WIND", "SP", "ERSHELL" 
$a -join "OW"
