﻿# Data types in PowerShell 
# --- string or character types 
cls 
$s1 = 10 
$s2= 20  
$sum = $s1 + $s2 
write-host " Adding $s1 and $s2 = " $sum 
#convert $s1 and $s2 to strings 
$s1 = $s1.ToString()  
$s2= $s2.ToString()
#Concatenate the two strings  
$sum = $s1 + $s2 
write-host "Concatenation of $s1 and $s2  "  $sum
 