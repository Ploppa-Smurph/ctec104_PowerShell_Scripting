﻿#strings 
cls
clear-host
$s1   =“Hello ”
$s2= “World” 
$s1
$s2
write-host $s1  $s2 
# numbers 
 $n1 =100
 $n1
 $n2 = 2000 
 $n2
$sum = $n1 + $n2
write-host " sum of two numbers: " $sum 
