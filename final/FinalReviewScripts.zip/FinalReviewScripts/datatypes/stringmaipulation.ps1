﻿cls
$n = "1000"
#string concatenation 
$n =$n + 99
write-host $n 
#use nemeric value of $n
$n="1000"  
$n =[int]$n 
$n =$n + 99
write-host $n 
$ans =read-host " Type any key to use split" 
$s = "one two three four"
#get-childitem 
$newstr = $s.Split()
$newstr 
$ans = read-host " press any key to use join " 
$p = "ahmed" 
$n ="--Arara" 
$p = -join $n
$q =  –join $p 
$p
$q