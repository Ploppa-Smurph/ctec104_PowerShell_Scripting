﻿cls 
$i= 10
if ($i -eq 10)
{ ' The number is 10 ' }
else 
{ ' The number is not 10'  }
