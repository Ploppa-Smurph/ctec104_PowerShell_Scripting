﻿cls
$process= get-process svchost*

foreach ($p in $process)
{  write-host $p.Name  "  " $p.Id $p.MainModule 
 
}
