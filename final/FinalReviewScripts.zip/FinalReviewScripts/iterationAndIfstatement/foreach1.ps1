﻿cls 
$k=0  
get-childitem "*.dll" | 
foreach-object {
   $k=$k+1
   write-host "FILE NO: " $k  "     " $_.name  ($k)
  }
write-host 
write-host 
write-host " Number of files with extension exe " $k


