﻿# to display all power shell files (.PS1) in the current directory
#.............
cls 
$k=0  
get-childitem "c:\windows\*.exe" | 
foreach-object {
   $k=$k+1
   write-host "FILE NO: " $k  "     " $_.name  }
write-host 
write-host 
write-host " Number of files with extension exe " $k


