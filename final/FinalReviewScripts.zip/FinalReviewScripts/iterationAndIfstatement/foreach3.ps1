cls
$dir = get-childitem zip*

foreach ($p in $dir)
{ write-host $p.lastwritetime 
  write-host  $p.name

}

