cls
$process= get-process i*

foreach ($p in $process)
{ $p.Name
  $p.GetType()

}

